import { GoogleGenAI, Type, Schema } from "@google/genai";
import { CandidateAnalysisResult, RecruiterAnalysisResult, CandidateInput } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Schema for Candidate Analysis
const candidateResponseSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    matchScore: { type: Type.INTEGER, description: "A score from 0 to 100 indicating fit." },
    summary: { type: Type.STRING, description: "A brief executive summary of the match." },
    matchingSkills: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          skill: { type: Type.STRING },
          relevance: { type: Type.INTEGER, description: "Importance of skill 0-100" },
          presentInResume: { type: Type.BOOLEAN }
        }
      }
    },
    missingSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
    experienceGaps: { type: Type.STRING, description: "Analysis of experience depth gaps." },
    improvementSuggestions: { type: Type.ARRAY, items: { type: Type.STRING } }
  },
  required: ["matchScore", "matchingSkills", "missingSkills", "improvementSuggestions", "summary", "experienceGaps"]
};

// Schema for Recruiter Ranking
const recruiterResponseSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    jobContext: { type: Type.STRING, description: "Brief extraction of key job requirements." },
    rankedCandidates: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          score: { type: Type.INTEGER },
          rationale: { type: Type.STRING },
          keyStrengths: { type: Type.ARRAY, items: { type: Type.STRING } }
        }
      }
    }
  },
  required: ["jobContext", "rankedCandidates"]
};

export const analyzeCandidateMatch = async (resumeText: string, jobDesc: string): Promise<CandidateAnalysisResult> => {
  if (!apiKey) throw new Error("API Key is missing");

  const prompt = `
    Act as an expert Technical Recruiter and ATS system. 
    Analyze the following Resume against the Job Description.
    Perform a semantic analysis, looking for depth of experience, transferable skills, and role relevance, not just keyword matching.
    
    Job Description:
    ${jobDesc}

    Resume:
    ${resumeText}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: candidateResponseSchema,
        systemInstruction: "You are an unbiased, data-driven hiring AI designed to provide transparent feedback."
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    return JSON.parse(text) as CandidateAnalysisResult;

  } catch (error) {
    console.error("Analysis failed:", error);
    throw error;
  }
};

export const rankCandidates = async (candidates: CandidateInput[], jobDesc: string): Promise<RecruiterAnalysisResult> => {
  if (!apiKey) throw new Error("API Key is missing");

  const candidatesPrompt = candidates.map((c, i) => `Candidate ${i + 1} (${c.name}):\n${c.resumeText}\n---`).join("\n");

  const prompt = `
    Act as a Senior Hiring Manager. 
    Rank the following candidates based on the Job Description provided.
    Focus on potential, relevant experience, and skill alignment.
    
    Job Description:
    ${jobDesc}

    Candidates:
    ${candidatesPrompt}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: recruiterResponseSchema,
        systemInstruction: "You are a fair, intelligent ranking system. Provide clear rationale for rankings."
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    return JSON.parse(text) as RecruiterAnalysisResult;

  } catch (error) {
    console.error("Ranking failed:", error);
    throw error;
  }
};