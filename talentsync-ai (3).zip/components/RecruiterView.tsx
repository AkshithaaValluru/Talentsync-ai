import React, { useState } from 'react';
import { rankCandidates } from '../services/geminiService';
import { RecruiterAnalysisResult, CandidateInput } from '../types';
import { Upload, Plus, Trash2, Award, Briefcase, ChevronRight, UserPlus, Sparkles } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const MOCK_CANDIDATES: CandidateInput[] = [
  {
    id: '1',
    name: 'Alex Chen',
    resumeText: 'Senior Full Stack Developer with 8 years experience in React, Node.js, and Python. Led a team of 5 developers at a FinTech startup. Strong background in AWS and microservices architecture. Certified AWS Solutions Architect.'
  },
  {
    id: '2',
    name: 'Sarah Jones',
    resumeText: 'Frontend Engineer passionate about UX/UI. 3 years experience with Vue.js and React. Skilled in Tailwind CSS and accessibility standards. Previous background in Graphic Design.'
  },
  {
    id: '3',
    name: 'Michael Miller',
    resumeText: 'Backend Java Developer with 15 years experience in legacy systems banking. Expert in Spring Boot and Oracle DB. Limited exposure to modern cloud infrastructure or JavaScript frameworks.'
  }
];

const RecruiterView: React.FC = () => {
  const [candidates, setCandidates] = useState<CandidateInput[]>(MOCK_CANDIDATES);
  const [jobDesc, setJobDesc] = useState<string>("");
  const [isRanking, setIsRanking] = useState(false);
  const [result, setResult] = useState<RecruiterAnalysisResult | null>(null);
  
  // State for new candidate modal/form
  const [newCandidateName, setNewCandidateName] = useState("");
  const [newCandidateResume, setNewCandidateResume] = useState("");
  const [showAddForm, setShowAddForm] = useState(false);

  const handleAddCandidate = () => {
    if (newCandidateName && newCandidateResume) {
      setCandidates([...candidates, {
        id: Date.now().toString(),
        name: newCandidateName,
        resumeText: newCandidateResume
      }]);
      setNewCandidateName("");
      setNewCandidateResume("");
      setShowAddForm(false);
    }
  };

  const removeCandidate = (id: string) => {
    setCandidates(candidates.filter(c => c.id !== id));
  };

  const handleRank = async () => {
    if (!jobDesc.trim()) return;
    setIsRanking(true);
    try {
      const data = await rankCandidates(candidates, jobDesc);
      setResult(data);
    } catch (error) {
      console.error(error);
      alert("Ranking failed. Check console.");
    } finally {
      setIsRanking(false);
    }
  };

  return (
    <div className="space-y-8">
      
      <div className="flex justify-between items-end">
         <div>
            <h2 className="text-3xl font-bold text-slate-900">Talent Ranking</h2>
            <p className="text-slate-500 mt-2">Evaluate multiple candidates simultaneously with AI.</p>
         </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Left Column: Job & Candidate Management */}
        <div className="lg:col-span-1 space-y-6">
          
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <h3 className="font-bold text-slate-800 mb-4 flex items-center">
              <Briefcase className="w-5 h-5 mr-2 text-violet-600" /> Job Requirements
            </h3>
            <textarea
              className="w-full h-40 p-4 text-sm bg-slate-50 border-0 rounded-xl focus:ring-2 focus:ring-violet-500 outline-none resize-none"
              placeholder="Paste job description..."
              value={jobDesc}
              onChange={(e) => setJobDesc(e.target.value)}
            />
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-slate-800 flex items-center">
                <UserPlus className="w-5 h-5 mr-2 text-fuchsia-600" /> Candidates
              </h3>
              <button 
                onClick={() => setShowAddForm(!showAddForm)}
                className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-600 transition-colors"
                title="Add Candidate"
              >
                <Plus className="w-5 h-5" />
              </button>
            </div>

            {showAddForm && (
              <div className="bg-fuchsia-50 p-4 rounded-xl mb-4 space-y-3 border border-fuchsia-100 animate-fade-in">
                <input 
                  type="text" 
                  placeholder="Name" 
                  className="w-full p-2 text-sm border-0 rounded-lg shadow-sm"
                  value={newCandidateName}
                  onChange={e => setNewCandidateName(e.target.value)}
                />
                <textarea 
                  placeholder="Resume Summary..." 
                  className="w-full p-2 text-sm border-0 rounded-lg shadow-sm h-20 resize-none"
                  value={newCandidateResume}
                  onChange={e => setNewCandidateResume(e.target.value)}
                />
                <button 
                  onClick={handleAddCandidate}
                  className="w-full bg-fuchsia-600 text-white text-xs font-bold py-2 rounded-lg hover:bg-fuchsia-700 transition-colors"
                >
                  Add to Pool
                </button>
              </div>
            )}

            <div className="space-y-3 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
              {candidates.map(c => (
                <div key={c.id} className="group flex justify-between items-start p-3 bg-slate-50 rounded-xl border border-slate-100 hover:border-violet-200 hover:shadow-sm transition-all">
                  <div>
                    <div className="font-bold text-slate-800 text-sm">{c.name}</div>
                    <div className="text-xs text-slate-500 line-clamp-2 mt-1">{c.resumeText}</div>
                  </div>
                  <button onClick={() => removeCandidate(c.id)} className="text-slate-400 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
              {candidates.length === 0 && (
                <div className="text-center py-6 text-slate-400 text-sm italic">No candidates added yet.</div>
              )}
            </div>
            
            <button
              onClick={handleRank}
              disabled={isRanking || candidates.length === 0 || !jobDesc}
              className={`mt-6 w-full py-4 rounded-xl font-bold text-white shadow-lg transition-all transform hover:-translate-y-1 ${
                isRanking 
                    ? 'bg-slate-400 cursor-not-allowed' 
                    : 'bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:shadow-violet-200'
              }`}
            >
              {isRanking ? (
                <span className="flex items-center justify-center">
                    <Sparkles className="w-4 h-4 mr-2 animate-pulse" /> Ranking...
                </span>
              ) : "Rank Candidates"}
            </button>
          </div>
        </div>

        {/* Right Column: Results */}
        <div className="lg:col-span-2">
          {!result ? (
            <div className="h-full flex flex-col items-center justify-center bg-slate-50/50 rounded-3xl border-2 border-dashed border-slate-200 text-slate-400 p-12 min-h-[400px]">
              <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-6">
                <Award className="w-10 h-10 text-slate-300" />
              </div>
              <p className="text-lg font-medium">Ready to evaluate?</p>
              <p className="text-sm">Add job details and candidate profiles, then click Rank.</p>
            </div>
          ) : (
            <div className="space-y-6 animate-fade-in">
              
              {/* Context Summary */}
              <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-xl shadow-slate-200">
                <h4 className="text-violet-300 text-xs font-bold uppercase tracking-wider mb-2">Evaluation Context</h4>
                <p className="text-sm text-slate-300 leading-relaxed">{result.jobContext}</p>
              </div>

              {/* Chart */}
              <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
                <h4 className="font-bold text-slate-800 mb-6">Candidate Scoreboard</h4>
                 <div className="h-64 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={result.rankedCandidates} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                            <XAxis type="number" domain={[0, 100]} hide />
                            <YAxis type="category" dataKey="name" width={100} tick={{fontSize: 12, fontWeight: 500, fill: '#475569'}} axisLine={false} tickLine={false} />
                            <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                            <Bar dataKey="score" radius={[0, 6, 6, 0]} barSize={24}>
                                {result.rankedCandidates.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={index === 0 ? '#8b5cf6' : index === 1 ? '#a78bfa' : '#cbd5e1'} />
                                ))}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                </div>
              </div>

              {/* List */}
              <div className="space-y-4">
                {result.rankedCandidates.map((c, index) => (
                  <div key={index} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 transition-all hover:shadow-md">
                    <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-4">
                            <span className={`flex items-center justify-center w-10 h-10 rounded-full font-bold text-sm shadow-sm ${index === 0 ? 'bg-yellow-100 text-yellow-700 ring-4 ring-yellow-50' : 'bg-slate-100 text-slate-600'}`}>
                                {index + 1}
                            </span>
                            <div>
                                <h3 className="text-lg font-bold text-slate-900">{c.name}</h3>
                                {index === 0 && <span className="text-xs font-semibold text-violet-600 bg-violet-50 px-2 py-0.5 rounded">Top Match</span>}
                            </div>
                        </div>
                        <div className="text-center">
                             <span className={`text-3xl font-extrabold ${index === 0 ? 'text-violet-600' : 'text-slate-400'}`}>{c.score}</span>
                        </div>
                    </div>
                    
                    <div className="bg-slate-50 p-4 rounded-xl mb-4">
                         <p className="text-slate-600 text-sm leading-relaxed">{c.rationale}</p>
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                        {c.keyStrengths.map((str, i) => (
                            <span key={i} className="px-2.5 py-1 bg-white text-slate-600 text-xs font-medium rounded-md border border-slate-200 shadow-sm">
                                {str}
                            </span>
                        ))}
                    </div>
                  </div>
                ))}
              </div>

            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RecruiterView;