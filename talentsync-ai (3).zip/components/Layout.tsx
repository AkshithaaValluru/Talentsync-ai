import React from 'react';
import { UserRole } from '../types';
import { Briefcase, User, Users, Sparkles } from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, currentRole, onRoleChange }) => {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div 
              className="flex items-center cursor-pointer gap-2 group" 
              onClick={() => onRoleChange(UserRole.HOME)}
            >
              <div className="relative">
                <div className="bg-violet-600 p-2 rounded-xl shadow-lg shadow-violet-200 group-hover:scale-105 transition-transform duration-200">
                  <Briefcase className="h-6 w-6 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 bg-fuchsia-500 rounded-full p-0.5 border-2 border-white">
                  <Sparkles className="h-3 w-3 text-white" />
                </div>
              </div>
              <span className="font-bold text-xl text-slate-900 tracking-tight">Talent<span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-600 to-fuchsia-600">Flow</span></span>
            </div>
            
            <nav className="flex space-x-2 md:space-x-4">
              <button
                onClick={() => onRoleChange(UserRole.CANDIDATE)}
                className={`flex items-center px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                  currentRole === UserRole.CANDIDATE 
                    ? 'bg-violet-50 text-violet-700 ring-1 ring-violet-200 shadow-sm' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <User className="w-4 h-4 mr-2" />
                Candidate
              </button>
              <button
                onClick={() => onRoleChange(UserRole.RECRUITER)}
                className={`flex items-center px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                  currentRole === UserRole.RECRUITER 
                    ? 'bg-fuchsia-50 text-fuchsia-700 ring-1 ring-fuchsia-200 shadow-sm' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                }`}
              >
                <Users className="w-4 h-4 mr-2" />
                Recruiter
              </button>
            </nav>
          </div>
        </div>
      </header>
      <main className="flex-grow w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>
      <footer className="bg-white border-t border-slate-200 mt-auto">
        <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-slate-500">
              © 2024 TalentFlow AI. All rights reserved.
            </p>
            <div className="flex space-x-6 text-sm text-slate-400">
              <span className="hover:text-violet-600 cursor-pointer">Privacy Policy</span>
              <span className="hover:text-violet-600 cursor-pointer">Terms of Service</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;