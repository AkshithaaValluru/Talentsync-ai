import React from 'react';
import { UserRole } from '../types';
import { User, Users, ArrowRight, CheckCircle2, Zap, Brain, ShieldCheck } from 'lucide-react';

interface DashboardHomeProps {
  onRoleSelect: (role: UserRole) => void;
}

const DashboardHome: React.FC<DashboardHomeProps> = ({ onRoleSelect }) => {
  return (
    <div className="flex flex-col items-center">
      
      {/* Hero Section */}
      <div className="w-full py-16 md:py-24 text-center">
        <div className="inline-flex items-center px-4 py-2 rounded-full bg-violet-50 border border-violet-100 text-violet-700 text-sm font-medium mb-8 animate-fade-in">
          <Zap className="w-4 h-4 mr-2 fill-violet-700" />
          Next-Gen AI Hiring
        </div>
        
        <h1 className="text-5xl md:text-7xl font-extrabold text-slate-900 mb-8 tracking-tight leading-tight max-w-5xl mx-auto">
          Hiring Intelligence <br/>
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-600 via-fuchsia-600 to-rose-500">
            Reimagined for Humans
          </span>
        </h1>
        
        <p className="max-w-2xl mx-auto text-xl text-slate-600 mb-12 leading-relaxed">
          Stop relying on keyword matching. Use advanced semantic AI to analyze resumes, identify skill gaps, and rank top talent with explainable insights.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-6 w-full max-w-2xl mx-auto">
          <button 
            onClick={() => onRoleSelect(UserRole.CANDIDATE)}
            className="w-full sm:w-auto group relative px-8 py-4 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-semibold shadow-xl shadow-slate-200 transition-all hover:-translate-y-1 flex items-center justify-center"
          >
            <User className="w-5 h-5 mr-3 text-violet-400" />
            <span>I'm a Job Seeker</span>
            <ArrowRight className="w-4 h-4 ml-2 opacity-0 group-hover:opacity-100 transition-all transform -translate-x-2 group-hover:translate-x-0" />
          </button>
          
          <button 
            onClick={() => onRoleSelect(UserRole.RECRUITER)}
            className="w-full sm:w-auto group relative px-8 py-4 bg-white border-2 border-slate-100 hover:border-fuchsia-200 text-slate-700 hover:text-fuchsia-700 rounded-2xl font-semibold shadow-lg shadow-slate-100 transition-all hover:-translate-y-1 flex items-center justify-center"
          >
            <Users className="w-5 h-5 mr-3 text-fuchsia-500" />
            <span>I'm Hiring Talent</span>
          </button>
        </div>
      </div>

      {/* Features Grid */}
      <div className="w-full max-w-6xl py-16 grid md:grid-cols-3 gap-8">
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-xl hover:border-violet-100 transition-all duration-300">
          <div className="w-12 h-12 bg-violet-100 rounded-2xl flex items-center justify-center mb-6">
            <Brain className="w-6 h-6 text-violet-600" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-3">Semantic Understanding</h3>
          <p className="text-slate-500 leading-relaxed">
            Our AI understands context, transferable skills, and experience depth—not just exact keyword matches.
          </p>
        </div>

        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-xl hover:border-fuchsia-100 transition-all duration-300">
          <div className="w-12 h-12 bg-fuchsia-100 rounded-2xl flex items-center justify-center mb-6">
            <CheckCircle2 className="w-6 h-6 text-fuchsia-600" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-3">Gap Analysis</h3>
          <p className="text-slate-500 leading-relaxed">
            Instantly identify missing qualifications and receive actionable suggestions to improve resume alignment.
          </p>
        </div>

        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-xl hover:border-rose-100 transition-all duration-300">
          <div className="w-12 h-12 bg-rose-100 rounded-2xl flex items-center justify-center mb-6">
            <ShieldCheck className="w-6 h-6 text-rose-600" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 mb-3">Unbiased Ranking</h3>
          <p className="text-slate-500 leading-relaxed">
            Standardize candidate evaluation with data-driven scoring, reducing unconscious bias in the screening process.
          </p>
        </div>
      </div>

      {/* Statistics / Trust Section */}
      <div className="w-full bg-slate-900 rounded-3xl p-12 mb-16 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-violet-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 -translate-y-1/2 translate-x-1/2"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-fuchsia-600 rounded-full mix-blend-multiply filter blur-3xl opacity-20 translate-y-1/2 -translate-x-1/2"></div>
        
        <div className="relative z-10 flex flex-col md:flex-row justify-around items-center gap-8 text-center md:text-left">
          <div>
            <div className="text-4xl font-bold text-white mb-2">93%</div>
            <div className="text-slate-400">Match Accuracy</div>
          </div>
          <div className="h-12 w-px bg-slate-700 hidden md:block"></div>
          <div>
            <div className="text-4xl font-bold text-white mb-2">2x</div>
            <div className="text-slate-400">Faster Screening</div>
          </div>
          <div className="h-12 w-px bg-slate-700 hidden md:block"></div>
          <div>
            <div className="text-4xl font-bold text-white mb-2">Instant</div>
            <div className="text-slate-400">Feedback Loop</div>
          </div>
        </div>
      </div>

    </div>
  );
};

export default DashboardHome;