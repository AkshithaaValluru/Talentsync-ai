import React, { useState } from 'react';
import { analyzeCandidateMatch } from '../services/geminiService';
import { CandidateAnalysisResult } from '../types';
import { Upload, FileText, CheckCircle, AlertCircle, TrendingUp, Search, Wand2, ArrowRight } from 'lucide-react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Tooltip } from 'recharts';

const TEMPLATES = [
  {
    name: "Senior Software Engineer",
    text: "ALEX RIVERA\nSenior Software Engineer\n\nSUMMARY\nExperienced Full Stack Engineer with 8+ years in building scalable web applications. Expert in React, Node.js, and Cloud Infrastructure. Passionate about code quality and team mentorship.\n\nSKILLS\nJavaScript (ES6+), TypeScript, React, Next.js, Node.js, AWS (Lambda, S3, DynamoDB), Docker, Kubernetes, CI/CD pipelines, System Design.\n\nEXPERIENCE\nTechFlow Inc. | Senior Developer | 2019 - Present\n- Led migration of legacy monolith to microservices, reducing deployment time by 40%.\n- Mentored 5 junior developers and established code review standards.\n- Architected high-traffic payment processing system handling $1M+ daily transactions.\n\nWebSolutions LLC | Full Stack Developer | 2015 - 2019\n- Developed 15+ custom web applications for e-commerce clients.\n- Integrated Stripe and PayPal APIs for secure payments."
  },
  {
    name: "Product Manager",
    text: "JORDAN LEE\nProduct Manager\n\nSUMMARY\nStrategic Product Manager with 5 years of experience in B2B SaaS. Proven track record of driving product adoption and leading cross-functional teams from ideation to launch.\n\nSKILLS\nProduct Strategy, Roadmap Planning, Agile/Scrum, User Research, A/B Testing, SQL, Jira, Figma, Stakeholder Management.\n\nEXPERIENCE\nInnovateSaaS | Product Manager | 2020 - Present\n- Launched core analytics feature increasing user retention by 25%.\n- Conducted 50+ user interviews to identify key pain points and prioritize roadmap.\n- Collaborated with engineering and design to deliver features on time.\n\nStartUp Alpha | Associate PM | 2018 - 2020\n- Managed backlog for mobile app team, improving sprint velocity by 15%."
  },
  {
    name: "Data Scientist",
    text: "CASEY SMITH\nData Scientist\n\nSUMMARY\nData Scientist specializing in machine learning and predictive analytics. Strong background in statistics and Python ecosystem. \n\nSKILLS\nPython, Pandas, Scikit-Learn, TensorFlow, SQL, Tableau, Data Visualization, Statistical Modeling, NLP.\n\nEXPERIENCE\nDataCorp | Data Scientist | 2021 - Present\n- Built churn prediction model improving customer retention strategies by 10%.\n- Automated data cleaning pipelines using Python and Airflow.\n- Presented insights to C-suite executives using Tableau dashboards.\n\nAnalysis Co. | Data Analyst | 2019 - 2021\n- Analyzed marketing campaign performance and optimized ad spend."
  }
];

const CandidateView: React.FC = () => {
  const [resumeText, setResumeText] = useState<string>("");
  const [jobDesc, setJobDesc] = useState<string>("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<CandidateAnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setResumeText(event.target?.result as string);
      };
      reader.readAsText(file);
    }
  };

  const loadTemplate = (templateText: string) => {
    setResumeText(templateText);
  };

  const handleAnalyze = async () => {
    if (!resumeText.trim() || !jobDesc.trim()) {
      setError("Please provide both a resume and a job description.");
      return;
    }
    setError(null);
    setIsAnalyzing(true);
    try {
      const analysis = await analyzeCandidateMatch(resumeText, jobDesc);
      setResult(analysis);
    } catch (err) {
      setError("Analysis failed. Please try again.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  // Prepare chart data
  const chartData = result?.matchingSkills.map(s => ({
    subject: s.skill,
    A: s.relevance, // Relevance
    B: s.presentInResume ? 100 : 20, // Presence score (simulated for visual)
    fullMark: 100
  })).slice(0, 6); // Top 6 skills for radar

  return (
    <div className="space-y-8">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-end mb-6">
        <div>
          <h2 className="text-3xl font-bold text-slate-900">Optimize Your Profile</h2>
          <p className="text-slate-500 mt-2">See how you match against any job description instantly.</p>
        </div>
      </div>

      {/* Input Section */}
      <div className="grid md:grid-cols-2 gap-6">
        
        {/* Resume Column */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col h-full">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-semibold text-lg text-slate-800 flex items-center">
              <FileText className="w-5 h-5 mr-2 text-violet-600" /> Resume / CV
            </h3>
            <div className="flex items-center gap-2">
               <div className="relative group">
                  <button className="text-xs bg-violet-50 hover:bg-violet-100 text-violet-700 px-3 py-1.5 rounded-md transition-colors flex items-center">
                    <Wand2 className="w-3 h-3 mr-1" /> Templates
                  </button>
                  {/* Templates Dropdown */}
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-slate-100 p-2 invisible opacity-0 group-hover:visible group-hover:opacity-100 transition-all z-10 transform origin-top-right">
                    <p className="text-xs font-semibold text-slate-400 px-2 py-1 uppercase tracking-wider">Load Example</p>
                    {TEMPLATES.map((t, i) => (
                      <button 
                        key={i}
                        onClick={() => loadTemplate(t.text)}
                        className="w-full text-left px-2 py-2 text-sm text-slate-700 hover:bg-violet-50 hover:text-violet-700 rounded-lg transition-colors"
                      >
                        {t.name}
                      </button>
                    ))}
                  </div>
               </div>

                <div className="relative">
                    <input 
                        type="file" 
                        id="resume-upload" 
                        className="hidden" 
                        accept=".txt,.md"
                        onChange={handleFileUpload}
                    />
                    <label 
                        htmlFor="resume-upload"
                        className="cursor-pointer text-xs bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1.5 rounded-md transition-colors flex items-center"
                    >
                        <Upload className="w-3 h-3 mr-1" /> Import
                    </label>
                </div>
            </div>
          </div>
          <textarea
            className="w-full flex-grow p-4 text-sm bg-slate-50 border-0 rounded-xl focus:ring-2 focus:ring-violet-500 outline-none resize-none font-mono text-slate-600 min-h-[300px]"
            placeholder="Paste your resume text here or choose a template..."
            value={resumeText}
            onChange={(e) => setResumeText(e.target.value)}
          ></textarea>
        </div>

        {/* Job Description Column */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col h-full">
          <h3 className="font-semibold text-lg text-slate-800 mb-4 flex items-center">
            <Search className="w-5 h-5 mr-2 text-fuchsia-600" /> Job Description
          </h3>
          <textarea
            className="w-full flex-grow p-4 text-sm bg-slate-50 border-0 rounded-xl focus:ring-2 focus:ring-fuchsia-500 outline-none resize-none font-mono text-slate-600 min-h-[300px]"
            placeholder="Paste the target job description here..."
            value={jobDesc}
            onChange={(e) => setJobDesc(e.target.value)}
          ></textarea>
        </div>
      </div>

      {/* Action Button */}
      <div className="flex flex-col items-center">
        {error && (
            <div className="flex items-center text-rose-600 bg-rose-50 px-4 py-2 rounded-lg mb-4 text-sm">
                <AlertCircle className="w-4 h-4 mr-2" />
                {error}
            </div>
        )}
        <button
          onClick={handleAnalyze}
          disabled={isAnalyzing || !resumeText || !jobDesc}
          className={`group px-8 py-4 rounded-2xl font-bold text-white shadow-xl shadow-violet-200 transition-all transform hover:-translate-y-1 flex items-center text-lg ${
            isAnalyzing 
                ? 'bg-slate-400 cursor-not-allowed shadow-none' 
                : 'bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:shadow-violet-300'
          }`}
        >
          {isAnalyzing ? (
            <span className="flex items-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Analyzing Profile...
            </span>
          ) : (
             <>
                Analyze Compatibility
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
             </>
          )}
        </button>
      </div>

      {/* Results Section */}
      {result && (
        <div className="space-y-6 animate-fade-in-up pb-12">
          
          {/* Header Score Card */}
          <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 relative overflow-hidden">
             {/* Background Decoration */}
             <div className="absolute top-0 right-0 w-64 h-64 bg-violet-50 rounded-full -translate-y-1/2 translate-x-1/2 opacity-50"></div>

            <div className="relative flex flex-col md:flex-row items-center justify-between gap-8">
                <div className="text-center md:text-left flex-1">
                    <div className="inline-flex items-center px-3 py-1 rounded-full bg-slate-100 text-slate-600 text-xs font-medium mb-3">
                        AI Assessment
                    </div>
                    <h2 className="text-3xl font-bold text-slate-900 mb-3">Match Analysis Report</h2>
                    <p className="text-slate-600 text-lg leading-relaxed">{result.summary}</p>
                </div>
                
                <div className="relative w-48 h-48 flex items-center justify-center flex-shrink-0">
                     {/* Circular Progress */}
                    <div 
                        className="w-full h-full rounded-full flex items-center justify-center bg-slate-100 shadow-inner"
                        style={{
                            background: `conic-gradient(${result.matchScore > 75 ? '#8b5cf6' : result.matchScore > 50 ? '#eab308' : '#f43f5e'} ${result.matchScore * 3.6}deg, #f1f5f9 0deg)`
                        }}
                    >
                        <div className="w-40 h-40 bg-white rounded-full flex flex-col items-center justify-center shadow-sm">
                            <span className={`text-5xl font-extrabold ${result.matchScore > 75 ? 'text-violet-600' : result.matchScore > 50 ? 'text-yellow-500' : 'text-rose-500'}`}>
                                {result.matchScore}%
                            </span>
                            <span className="text-sm uppercase font-bold text-slate-400 tracking-wider mt-1">Match Score</span>
                        </div>
                    </div>
                </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-6">
            
            {/* Chart Column */}
            <div className="lg:col-span-1 bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex flex-col">
                <h4 className="font-bold text-slate-800 mb-6 flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2 text-violet-600" /> Skill Alignment
                </h4>
                <div className="flex-grow w-full min-h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                        <RadarChart cx="50%" cy="50%" outerRadius="70%" data={chartData}>
                        <PolarGrid stroke="#e2e8f0" />
                        <PolarAngleAxis dataKey="subject" tick={{fontSize: 11, fill: '#64748b'}} />
                        <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false}/>
                        <Radar name="Job Requirement" dataKey="A" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.2} />
                        <Radar name="Your Profile" dataKey="B" stroke="#10b981" fill="#10b981" fillOpacity={0.2} />
                        <Tooltip contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}} />
                        </RadarChart>
                    </ResponsiveContainer>
                </div>
                <div className="flex justify-center gap-4 text-xs text-slate-500 mt-4">
                    <div className="flex items-center"><div className="w-2 h-2 rounded-full bg-violet-500 mr-1"></div> Required</div>
                    <div className="flex items-center"><div className="w-2 h-2 rounded-full bg-emerald-500 mr-1"></div> You</div>
                </div>
            </div>

            {/* Recommendations Column */}
            <div className="lg:col-span-2 grid gap-6">
                
                {/* Gaps & Improvements */}
                <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
                    <h4 className="font-bold text-slate-800 mb-6 flex items-center">
                        <AlertCircle className="w-5 h-5 mr-2 text-rose-500" /> Critical Insights
                    </h4>
                    
                    <div className="space-y-6">
                        <div className="p-5 bg-slate-50 rounded-2xl border border-slate-100">
                            <h5 className="text-sm font-bold text-slate-700 mb-2 uppercase tracking-wide">Experience Analysis</h5>
                            <p className="text-sm text-slate-600 leading-relaxed">{result.experienceGaps}</p>
                        </div>
                        
                        <div>
                            <h5 className="text-sm font-bold text-slate-700 mb-3 uppercase tracking-wide">Missing Key Skills</h5>
                            <div className="flex flex-wrap gap-2">
                                {result.missingSkills.map((skill, i) => (
                                    <span key={i} className="px-3 py-1.5 bg-rose-50 text-rose-700 text-sm font-medium rounded-lg border border-rose-100">
                                        {skill}
                                    </span>
                                ))}
                                {result.missingSkills.length === 0 && <span className="text-sm text-emerald-600 font-medium flex items-center"><CheckCircle className="w-4 h-4 mr-2"/> Great job! No major skills missing.</span>}
                            </div>
                        </div>

                        <div className="pt-4 border-t border-slate-100">
                            <h5 className="text-sm font-bold text-slate-700 mb-3 uppercase tracking-wide">AI Suggestions</h5>
                            <ul className="space-y-3">
                                {result.improvementSuggestions.map((suggestion, i) => (
                                    <li key={i} className="flex items-start text-sm text-slate-600 bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
                                        <Wand2 className="w-4 h-4 mr-3 text-violet-500 mt-0.5 flex-shrink-0" />
                                        {suggestion}
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CandidateView;