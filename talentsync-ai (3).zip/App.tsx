import React, { useState } from 'react';
import Layout from './components/Layout';
import DashboardHome from './components/DashboardHome';
import CandidateView from './components/CandidateView';
import RecruiterView from './components/RecruiterView';
import { UserRole } from './types';

const App: React.FC = () => {
  const [role, setRole] = useState<UserRole>(UserRole.HOME);

  const renderContent = () => {
    switch (role) {
      case UserRole.CANDIDATE:
        return <CandidateView />;
      case UserRole.RECRUITER:
        return <RecruiterView />;
      case UserRole.HOME:
      default:
        return <DashboardHome onRoleSelect={setRole} />;
    }
  };

  return (
    <Layout currentRole={role} onRoleChange={setRole}>
      <div className="animate-fade-in-up">
        {renderContent()}
      </div>
    </Layout>
  );
};

export default App;