export enum UserRole {
  CANDIDATE = 'CANDIDATE',
  RECRUITER = 'RECRUITER',
  HOME = 'HOME'
}

export interface SkillMatch {
  skill: string;
  relevance: number; // 0-100
  presentInResume: boolean;
}

export interface CandidateAnalysisResult {
  matchScore: number;
  summary: string;
  matchingSkills: SkillMatch[];
  missingSkills: string[];
  experienceGaps: string;
  improvementSuggestions: string[];
}

export interface RankedCandidate {
  name: string;
  score: number;
  rationale: string;
  keyStrengths: string[];
}

export interface RecruiterAnalysisResult {
  jobContext: string;
  rankedCandidates: RankedCandidate[];
}

export interface CandidateInput {
  id: string;
  name: string;
  resumeText: string;
}